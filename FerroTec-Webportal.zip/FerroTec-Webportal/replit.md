# FerroTec - Industrial Metal Manufacturing Website

## Overview

A German industrial manufacturing company website built as a single-page application. The site showcases metal casting and CNC machining services with a modern, professional design. Features a contact form that stores inquiries in a PostgreSQL database.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side navigation
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **UI Components**: shadcn/ui component library (New York style)
- **Animations**: Framer Motion for scroll animations and transitions
- **Smooth Scrolling**: react-scroll for navigation links
- **State Management**: TanStack React Query for server state
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ESM modules
- **Build Tool**: esbuild for server bundling, Vite for client
- **API Pattern**: REST endpoints defined in shared routes file with Zod schemas

### Data Storage
- **Database**: PostgreSQL via node-postgres (pg)
- **ORM**: Drizzle ORM with drizzle-zod for schema validation
- **Schema Location**: `shared/schema.ts` contains all database tables
- **Migrations**: Drizzle Kit with `db:push` command

### Project Structure
```
├── client/           # React frontend
│   └── src/
│       ├── components/   # UI components including shadcn/ui
│       ├── hooks/        # Custom React hooks
│       ├── lib/          # Utilities and query client
│       └── pages/        # Page components
├── server/           # Express backend
│   ├── db.ts         # Database connection
│   ├── routes.ts     # API route handlers
│   └── storage.ts    # Data access layer
├── shared/           # Shared code between client/server
│   ├── schema.ts     # Drizzle database schemas
│   └── routes.ts     # API route definitions with Zod
└── migrations/       # Database migrations
```

### Key Design Patterns
- **Shared Schema**: Database schema and API types shared between frontend and backend
- **Type-Safe API**: Route definitions include input/output schemas validated with Zod
- **Storage Abstraction**: Database operations abstracted through storage interface
- **Component Library**: shadcn/ui components customized with industrial theme

## External Dependencies

### Database
- **PostgreSQL**: Primary database accessed via `DATABASE_URL` environment variable
- **Connection**: Uses pg Pool for connection management

### Third-Party Services
- None currently configured (contact form stores to database only)

### Key NPM Packages
- `drizzle-orm` / `drizzle-kit`: Database ORM and migrations
- `@tanstack/react-query`: Server state management
- `framer-motion`: Animation library
- `react-scroll`: Smooth scrolling navigation
- `zod`: Runtime type validation
- `react-hook-form`: Form state management
- Full shadcn/ui component set via Radix UI primitives