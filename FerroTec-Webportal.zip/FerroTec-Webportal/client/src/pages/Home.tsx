import { motion } from "framer-motion";
import { Link } from "react-scroll";
import { ArrowDown, CheckCircle2, Factory, Award, TrendingUp } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { ServicesSection } from "@/components/ServicesSection";
import { ContactSection } from "@/components/ContactForm";
import { Button } from "@/components/ui/button";

import footerLogoUrl from "@assets/IMG_0436_1766866222674.jpeg";

export default function Home() {
  return (
    <div className="min-h-screen bg-background font-sans text-foreground overflow-x-hidden">
      <Navbar />

      {/* Hero Section */}
      <section id="home" className="relative min-h-[600px] flex items-center justify-center pt-20">
        <div className="absolute inset-0 z-0 bg-black">
          <img 
            src="https://images.unsplash.com/photo-1565610222536-ef125c59da2e?q=80&w=2070&auto=format&fit=crop" 
            alt="Industrielle Fertigung" 
            className="w-full h-full object-cover opacity-60"
          />
        </div>

        <div className="container mx-auto px-4 md:px-6 relative z-10 text-center">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-4xl mx-auto"
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-medium mb-4 text-white">
              Ihr globaler Partner für Grauguss
            </h1>
            <p className="text-lg md:text-xl text-accent uppercase tracking-[0.2em] font-medium mb-12">
              ENTWICKLUNG - GIESSEREI - BEARBEITUNG
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="contact" smooth={true} offset={-80}>
                <Button size="lg" className="bg-secondary/20 text-white border-white hover:bg-white/10 border-2 shadow-lg hover:shadow-primary/20 rounded-none px-8">
                  Kontakt aufnehmen
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Product Slider Placeholder (Visual match for screenshot 1) */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex justify-center items-center gap-8 overflow-x-auto py-8 no-scrollbar grayscale opacity-70">
            {/* Simple representation of the product row in screenshot 1 */}
            {[1, 2, 3, 4, 5, 6, 7, 8].map(i => (
              <div key={i} className="min-w-[80px] h-[80px] bg-muted/20 rounded-lg flex items-center justify-center">
                <div className="w-12 h-12 bg-muted rounded" />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Über Uns Section / Kokillenguss mit Sicherheit */}
      <section id="about" className="py-24 bg-[#f8f9fa]">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="lg:col-span-7"
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-primary">Kokillenguss mit Sicherheit</h2>
              <h3 className="text-xl text-muted-foreground mb-8">FerroTec GmbH - Gießerei und maschinelle Bearbeitung</h3>
              <div className="space-y-6 text-base text-muted-foreground leading-relaxed">
                <p>
                  Wir sind europaweit der größte Hersteller von Kupplungs- und Bremsbauteilen für die Automobil- und Nutzfahrzeugindustrie...
                </p>
                <p>
                  Unser deutschlandweites Alleinstellungsmerkmal ist der Kokillenguss im Bereich von 0,1kg - 10kg Bauteile...
                </p>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="lg:col-span-5 flex flex-col items-center lg:items-end justify-center pt-8"
            >
              <div className="bg-white p-8 shadow-sm border border-border flex items-center gap-4">
                <div className="text-right">
                  <div className="text-sm font-bold text-primary">ISO 9001</div>
                  <div className="text-xs uppercase tracking-tighter">BUREAU VERITAS</div>
                  <div className="text-xs">Certification</div>
                </div>
                <div className="w-16 h-16 bg-primary flex items-center justify-center text-white font-bold">BV</div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <ServicesSection />

      {/* Qualität Section */}
      <section id="quality" className="py-24 bg-primary text-white overflow-hidden">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-16 max-w-3xl mx-auto">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">Unser Qualitätsversprechen</h2>
            <p className="text-lg text-white/80">
              Qualität ist kein Zufall, sondern das Ergebnis intelligenter Planung und engagierter Arbeit.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: Award,
                title: "Zertifizierte Prozesse",
                desc: "Unsere Abläufe sind nach ISO 9001 zertifiziert und unterliegen ständigen Kontrollen."
              },
              {
                icon: Factory,
                title: "Moderner Maschinenpark",
                desc: "Wir investieren kontinuierlich in modernste Fertigungstechnologien für beste Ergebnisse."
              },
              {
                icon: TrendingUp,
                title: "Kontinuierliche Verbesserung",
                desc: "Null-Fehler-Strategie und stetige Optimierung sind Teil unserer DNA."
              }
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ 
                  delay: i * 0.2,
                  type: "spring",
                  stiffness: 100,
                  damping: 15
                }}
                whileHover={{ y: -10, transition: { duration: 0.3 } }}
                className="bg-white/10 backdrop-blur-sm p-8 rounded-2xl border border-white/10 hover:bg-white/20 transition-all duration-300 shadow-xl"
              >
                <motion.div
                  animate={{ 
                    y: [0, -5, 0],
                  }}
                  transition={{ 
                    duration: 4, 
                    repeat: Infinity, 
                    ease: "easeInOut",
                    delay: i * 0.5
                  }}
                >
                  <item.icon className="w-12 h-12 mb-6 text-accent" />
                </motion.div>
                <h3 className="text-2xl font-bold mb-4">{item.title}</h3>
                <p className="text-white/70 leading-relaxed">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <ContactSection />

      {/* Footer */}
      <footer className="bg-[#212529] text-white py-16 border-t border-white/10">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col items-center mb-16">
             <img src={footerLogoUrl} alt="FerroTec Footer Logo" className="h-24 w-auto mb-4" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
            <div className="lg:col-span-1">
              {/* Empty space matching screenshot layout */}
            </div>
            
            <div>
              <h4 className="text-lg font-bold mb-6">Leistungen</h4>
              <ul className="space-y-3">
                {['Qualität', 'Material', 'Zugfestigkeit', 'Konstruktion', 'Die Kokille'].map(item => (
                  <li key={item} className="flex items-center gap-2 text-white/60 hover:text-white transition-colors">
                    <span className="text-xs">›</span> {item}
                  </li>
                ))}
              </ul>
            </div>

            <div className="lg:col-span-1">
              {/* Empty space matching screenshot layout */}
            </div>

            <div>
              <h4 className="text-lg font-bold mb-6">Kontakt</h4>
              <div className="text-white/60 space-y-4">
                <p>
                  FerroTec GmbH<br/>
                  Eyßelheideweg 12<br/>
                  38518 Gifhorn
                </p>
                <p>
                  +49 5371 81610<br/>
                  info@ferrotec-gifhorn.de
                </p>
              </div>
            </div>
          </div>
          
          <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-white/40">
            <p>Copyright 2019 © All Rights Reserved</p>
            <div className="flex gap-4">
              <a href="#" className="hover:text-white">Impressum</a>
              <span>|</span>
              <a href="#" className="hover:text-white">Datenschutz</a>
              <span>|</span>
              <a href="#" className="hover:text-white">ALB</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
