import { Link } from "react-scroll";
import { useState, useEffect } from "react";
import { Button } from "./ui/button";
import { Menu, X } from "lucide-react";
import { cn } from "@/lib/utils";

import logoUrl from "@assets/IMG_0435_1766866222675.jpeg";

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { name: "Start", to: "home" },
    { name: "Über Uns", to: "about" },
    { name: "Qualität", to: "quality" },
  ];

  return (
    <nav
      className={cn(
        "fixed top-0 w-full z-50 transition-all duration-300 bg-white border-b border-border shadow-sm py-4"
      )}
    >
      <div className="container mx-auto px-4 md:px-6 flex justify-between items-center">
        <Link 
          to="home" 
          smooth={true} 
          className="cursor-pointer"
        >
          <img src={logoUrl} alt="FerroTec Logo" className="h-12 w-auto" />
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <Link
              key={link.name}
              to={link.to}
              smooth={true}
              offset={-80}
              className="text-sm font-semibold uppercase tracking-wider text-primary/80 hover:text-primary cursor-pointer transition-colors"
            >
              {link.name}
            </Link>
          ))}
          <Link to="contact" smooth={true} offset={-80}>
            <Button>Kontakt</Button>
          </Link>
        </div>

        {/* Mobile Toggle */}
        <button
          className="md:hidden text-primary"
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? <X className="h-8 w-8" /> : <Menu className="h-8 w-8" />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden absolute top-full left-0 w-full bg-white border-b border-border shadow-xl p-4 flex flex-col gap-4">
          {navLinks.map((link) => (
            <Link
              key={link.name}
              to={link.to}
              smooth={true}
              offset={-80}
              onClick={() => setIsOpen(false)}
              className="text-lg font-bold text-primary py-2 px-4 hover:bg-muted rounded-lg"
            >
              {link.name}
            </Link>
          ))}
          <Link to="contact" smooth={true} offset={-80} onClick={() => setIsOpen(false)}>
            <Button className="w-full">Kontakt aufnehmen</Button>
          </Link>
        </div>
      )}
    </nav>
  );
}
