import { motion } from "framer-motion";
import { Settings, Cog, Component, ShieldCheck, Ruler, ArrowRight } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

import img1 from "@assets/IMG_0431_1766866222675.jpeg";
import img2 from "@assets/IMG_0430_1766866222675.png";
import img3 from "@assets/IMG_0429_1766866222675.jpeg";
import img4 from "@assets/IMG_0432_1766866222675.jpeg";
import img5 from "@assets/IMG_0433_1766866222675.jpeg";
import img6 from "@assets/IMG_0434_1766866222675.jpeg";

const services = [
  {
    icon: Component,
    title: "Die Kokille",
    description: "Unsere Kokillen werden nach CAD System mit CNC Fräsen gefertigt. Der Prozess läuft sehr schnell und sehr genau ab.",
    image: img1
  },
  {
    icon: Cog,
    title: "Material",
    description: "Gusseisen mit Lamellengraphit - Das Schliffbild zeigt das typische Gefüge unserer kernlos in Kokillen (Dauerformen) vergossenen Legierung.",
    image: img2
  },
  {
    icon: Settings,
    title: "Zugfestigkeit",
    description: "Unser Guss wird hinsichtlich der Zugfestigkeit computergesteuert geprüft. Wir garantieren Ihnen somit eine höchste Qualität.",
    image: img3
  },
  {
    icon: ShieldCheck,
    title: "Qualität",
    description: "Unsere Qualität findet ihren Ursprung in der Entwicklung, dem Modellbau und der Prozesssteuerung in der Gießerei.",
    image: img4
  },
  {
    icon: Ruler,
    title: "Kerne",
    description: "Auch die Herstellung der Kerne erfolgt vollautomatisch mittels EDV gestützten Abläufen.",
    image: img5
  },
  {
    icon: ArrowRight,
    title: "Konstruktion & Prüfung",
    description: "In der Konstruktion arbeiten wir mit moderner EDV und Software. Die Gusserzeugnisse werden stetig auf Maßhaltigkeit mittels 3D Messverfahren geprüft.",
    image: img6
  }
];

export function ServicesSection() {
  return (
    <section id="quality" className="py-24 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16 max-w-2xl mx-auto"
        >
          <h2 className="text-4xl font-light mb-6 text-primary">Qualität</h2>
          <div className="w-12 h-px bg-border mx-auto mb-6" />
          <p className="text-muted-foreground">
            Wir bieten eine breite Palette von Dienstleistungen für kleine und große Projekte
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              whileHover={{ 
                y: -8,
                transition: { duration: 0.3, ease: "easeOut" }
              }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group relative bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 border border-border/50"
            >
              <div className="h-64 overflow-hidden grayscale group-hover:grayscale-0 transition-all duration-700">
                <img 
                  src={service.image} 
                  alt={service.title} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" 
                />
              </div>
              <div className="p-8 text-center">
                <motion.div
                  initial={{ scale: 1 }}
                  whileHover={{ scale: 1.05 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <h3 className="text-xl font-semibold mb-4 text-primary">{service.title}</h3>
                </motion.div>
                <p className="text-sm text-muted-foreground mb-6 line-clamp-3 leading-relaxed">{service.description}</p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="rounded-full px-8 uppercase text-[10px] tracking-widest border-primary/20 text-primary hover:bg-primary hover:text-white transition-all duration-300"
                >
                  mehr dazu
                </Button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
