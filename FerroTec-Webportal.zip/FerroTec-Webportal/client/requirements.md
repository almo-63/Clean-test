## Packages
framer-motion | Complex scroll animations and transitions
react-scroll | Smooth scrolling for navigation links
clsx | Utility for conditional classes
tailwind-merge | Utility for merging tailwind classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["var(--font-sans)"],
  display: ["var(--font-display)"],
}
